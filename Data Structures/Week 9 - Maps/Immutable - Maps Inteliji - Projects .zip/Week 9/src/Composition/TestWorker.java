public class TestWorker {

    public static void main(String[] args) {
        Worker mWorker = new Worker();
        long salary = mWorker.getSalary();
        System.out.println(salary);
    }

}