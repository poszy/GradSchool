package bet;

/**
 * @author Charl
 *
 */
public interface List<E extends Comparable<E>> extends Collection<E> {

}
