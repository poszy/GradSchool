public class Car extends Vehicle {
    void type(){ System.out.println("This Vehicle is a car");}
    void honk(){System.out.println("Beep! Beep!");}
}
