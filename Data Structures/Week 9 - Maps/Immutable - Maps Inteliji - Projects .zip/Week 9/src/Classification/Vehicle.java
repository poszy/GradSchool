public class Vehicle {
    void drive(){ System.out.println("This Vehicle is now driving");}
    void stop(){ System.out.println("This Vehicle is now stopping");}
}
