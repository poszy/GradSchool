public class HondaCar extends Car {
    void activateHondaBoosters(){System.out.println("Activating Turbo Boosters only available in hondas");}
}
