package com.infix;

public class InvalidOperatorException extends Exception {
    /**
     *
     */
    private static final long serialVersionUID = 1L;

    public InvalidOperatorException() {
    }

    public InvalidOperatorException(String msg) {
        super(msg);
    }
}